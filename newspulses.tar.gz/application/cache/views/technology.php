  <div class="main-content">
                        <!-- Trending line -->
                        <div class="trending-posts-line">
                            <div class="container">
                                <div class="trending-line" id="js-top-headlines">

                                </div>
                            </div>
                        </div>
                        <!-- Trending line END -->
                        <!-- Main posts -->
                        <div class="main-posts-1">
                           
                            <div class="mp-section" style="height: 258px" id="js-top-section">
                        
                            </div>
                        </div>
                        <!-- Main posts END -->
                  
                        <!-- Video data was here-->
                        <div class="section">
                            <div class="row">
                                <div class="content">

                                    <div class="latest-nws">
                                        <div class="pst-block">
                                            <div class="pst-block-head">
                                                <h2 class="title-4"><strong>Latest </strong> News</h2>
                                             
                                            </div>
                                            <div class="pst-block-main">
                                                <div class="col-row" id="js-main-content">
                                        
                                                </div>
                                                <!-- Page nav -->
                                                <div class="page-nav" id="js-pagination">
                                                    <a href="#" class="pn-item">
                                                        <i class="page-nav-prev-ic"></i>
                                                    </a>
                                                    <a href="#" class="pn-item mb-pt-hide current" value="9">1</a>
                                                    <a href="#" class="pn-item mb-pt-hide" value="9">2</a>
                                                    <a href="#" class="pn-item mb-pt-hide" value="14">3</a>
                                                     <a href="#" class="pn-item mb-pt-hide" value="19">4</a>
                                                      <a href="#" class="pn-item mb-pt-hide" value="24">5</a>
                                                    <a href="#" class="pn-item">
                                                    <i class="page-nav-next-ic"></i>
                                                    </a>
                                                    <span class="page-count">Page 1 of 3</span>
                                                </div>
                                                <!-- Page nav END -->
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <aside class="side-bar">
                                    <div class="tags-widget">
                                        <div class="pst-block">
                                            <div class="pst-block-head">
                                                <h2 class="title-4"><strong>Tags</strong></h2>
                                                <div class="all-sb">
                                                    <a href="index._slideTemplatel">all tags</a>
                                                </div>
                                            </div>
                                            <div class="pst-block-main">
                                                <div class="tags-block">
                                                    <ul class="tags-list">
                                                        <li><a href="index._slideTemplatel">Apple</a></li>
                                                        <li><a href="index._slideTemplatel">news</a></li>
                                                        <li><a href="index._slideTemplatel">clear</a></li>
                                                        <li><a href="index._slideTemplatel">design</a></li>
                                                        <li><a href="index._slideTemplatel">magazine</a></li>
                                                        <li><a href="index._slideTemplatel">life style</a></li>
                                                        <li><a href="index._slideTemplatel">ui/ux</a></li>
                                                        <li><a href="index._slideTemplatel">popular</a></li>
                                                        <li><a href="index._slideTemplatel">fashion</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="sb-banner">
                                        <div class="banner-inner">
                                            <img src="https://s3.amazonaws.com/weblionmedia-spectr/img/sb-banner-img.jpg" height="270" width="320" alt="Spectr News Theme" class="adaptive" />
                                            <div class="banner-overlay">
                                                <h5 class="title-11">The Best <br>Magazine &amp; Blog <br>Theme</h5>
                                                <a href="index._slideTemplatel" class="btn-2">buy it now</a>
                                            </div>
                                        </div>
                                    </div>
                    
                                

                                    <div class="weather-widget">
                                        <div class="pst-block">
                                            <div class="pst-block-head">
                                                <h2 class="title-4"><strong><i class="li_location"></i> Vienna</strong></h2>
                                                <a href="index._slideTemplatel" class="arr-ic-3"></a>
                                            </div>
                                            <div class="pst-block-main">
                                                <div class="weather-block">
                                                    <div class="temperature">
                                                        <i class="weather-icon-clouds-flash-alt"></i>
                                                        <span class="degrees-1">24<i class="degrees-ic-1"></i></span>
                                                        <div class="day">wednesday</div>
                                                    </div>
                                                    <ul>
                                                        <li>Rain</li>
                                                        <li>humidity: 55%</li>
                                                        <li>wind: 3km/h NW</li>
                                                        <li>H 26 • L 26</li>
                                                    </ul>
                                                </div>
                                                <hr class="pst-block-hr">
                                                <div class="weather-days">
                                                    <ul class="weather-days-list">
                                                        <li>
                                                            <a href="index._slideTemplatel">
                                                                <span class="degrees-2">27<i class="degrees-ic-2"></i></span>
                                                                <div class="day">thusday</div>
                                                            </a>
                                                        </li>
                                                        <li class="active">
                                                            <a href="index._slideTemplatel">
                                                                <span class="degrees-2">25<i class="degrees-ic-2"></i></span>
                                                                <div class="day">friday</div>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="index._slideTemplatel">
                                                                <span class="degrees-2">26<i class="degrees-ic-2"></i></span>
                                                                <div class="day">satuday</div>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="index._slideTemplatel">
                                                                <span class="degrees-2">27<i class="degrees-ic-2"></i></span>
                                                                <div class="day">sunday</div>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="index._slideTemplatel">
                                                                <span class="degrees-2">23<i class="degrees-ic-2"></i></span>
                                                                <div class="day">monday</div>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="pst-block">
                                        <div class="pst-block-head">
                                            <h2 class="title-4"><strong>Stay</strong> Connected</h2>
                                        </div>
                                        <div class="pst-block-main">
                                            <div class="social-tp-1">
                                                <ul class="social-list">
                                                    <li class="fb">
                                                        <a href="index._slideTemplatel">
                                                            <span class="soc-ic">
                                                                <i class="fa fa-facebook"></i>
                                                            </span> 1526 Fans
                                                            <span class="soc-btn">Like It</span>
                                                        </a>
                                                    </li>
                                                    <li class="tw">
                                                        <a href="index._slideTemplatel">
                                                            <span class="soc-ic">
                                                                <i class="fa fa-twitter"></i>
                                                            </span> 541 Followers
                                                            <span class="soc-btn">Follow Us</span>
                                                        </a>
                                                    </li>
                                                    <li class="gp">
                                                        <a href="index._slideTemplatel">
                                                            <span class="soc-ic">
                                                                <i class="fa fa-google-plus"></i>
                                                            </span> 421 Friends
                                                            <span class="soc-btn">Follow Us</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>




  <script type="text/javascript">

    (function (window, $, undefined) {

        // var navScope = $(".navbar-collapse");
        // app._getTopHeadLines();
        var queryCatg = {key: 'technology'};
        var url = 'category';
        app._getCategory(queryCatg,url).done(function(data){
                $('#js-top-section').html('');
                 $('#js-main-content').html('');
              var i = 10;
                var j = 10;
                var _category = '';
                var _content = '';
                $.each(data, function (key, news) {
                     news = JSON.parse(news);
                        if ((key < 3)) {
                            _category += '<div class="one-third sm-half"><article class="post post-tp-2"><figure>';
                            _category += '<a href="index._slideTemplatel"><img src="' + news.multimedia[2].url + '" height="258" width="380" alt="Spectr News Theme" class="adaptive" /></a>';
                            _category += '</figure><div class="ptp-1-overlay"><div class="ptp-1-data">';
                            _category += '<a href="index._slideTemplatel" class="category-tp-1">BUSINESS</a>';
                            _category += '  <h2 class="title-29"><a  href="' + news.url + '" target="_blank">' +news.abstract+ '</a></h2>';
                            _category += '<div class="meta-tp-1"><div class="ptp-1-date"><a href="index._slideTemplatel">october 2, 2015</a></div>';
                             _category += ' <div class="ptp-1-views"><a href="index._slideTemplatel"><i class="li_eye"></i><span>187</span></a></div>';
                             _category += ' <div class="ptp-1-comments"><a href="index._slideTemplatel"><i class="li_bubble"></i><span>5</span></a></div>';
                             _category +='</div></div></div></article></div>';

                        }
                       if(key > 4 ){
                          if(key < i){
                            _content += '<article class="post post-tp-6" value="'+key+'">';
                            _content += '<figure class="js-category-news">';
                            _content += ' <a href="index._slideTemplatel"><img src="' + news.multimedia[2].url  + '" height="85" width="115" alt="Spectr News Theme" class="adaptive" /></a>';
                            _content += '</figure>';
                            _content += '<h3 class="title-6"><a href="' + news.url + '" target="_blank"</a>' +news.abstract+  '</h3>';
                            _content += '<div class="date-tp-2">october 2, 2015</div></article>';
                          }else{
                            _content += '<article class="post post-tp-6" style="display:none" value="'+key+'">';
                            _content += '<figure class="js-category-news">';
                            _content += ' <a href="index._slideTemplatel"><img src="' + news.multimedia[2].url  + '" height="85" width="115" alt="Spectr News Theme" class="adaptive" /></a>';
                            _content += '</figure>';
                            _content += '<h3 class="title-6"><a href="' + news.url + '" target="_blank"</a>' +news.abstract+  '</h3>';
                            _content += '<div class="date-tp-2">october 2, 2015</div></article>';
                          }
               
                      
                       } 
                    

                });
                $('#js-top-section').html(_category);
                $('#js-main-content').html(_content);

        });
       
      $('#js-pagination').on('click','.pn-item',function(evt){

            evt.preventDefault();
            var num1 = parseInt($(this).attr("value"));
            var htm = $('#js-main-content').find('article');

            $(htm).each(function(index,data){
             var num2 =  $(data).attr('value')
             if(num2 < num1){
                 $(data ,'article').hide();

             }
             if((num2 > num1) && (num2 < (num1 + 5))){
                $(data ,'article').show();
             }

            });
              
        
            // var htm = $('#js-main-content').find('article')[0];
            // $(htm ,'article').hide();


      });

    })(window, jQuery);
</script>