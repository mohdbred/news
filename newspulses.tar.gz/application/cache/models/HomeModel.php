<?php
class HomeModel extends Model {

 function HomeModel(){
  parent::Model();
 }

 function getEmployees(){
  $this->db->select("data");
  $this->db->from('art');
  $query = $this->db->get();
  return $query->result();
 }
}
?>